"""
Объявите в программе функцию, которая не имеет параметров и просто выводит на экран следующую строку:

It's my first function

После объявления вызовите эту функцию.
"""


def print_message():
    print("It's my first function")


print_message()
