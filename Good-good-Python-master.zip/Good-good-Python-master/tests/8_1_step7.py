"""
Из модуля random импортируйте только две функции: seed и randint. Затем, в программе выполните их следующим образом:

seed(1)
print(randint(10, 50))
"""

from random import seed, randint

seed(1)
print(randint(10, 50))
